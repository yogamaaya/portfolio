---
name: Breath page performance
description: Constraints that keep /breath from being killed and reloaded by the browser (esp. mobile).
---

# /breath performance constraints

**Rule 1: no per-character `filter: blur()` animations.** CharFade animates opacity + transform ONLY.
**Why:** the page staggers hundreds of per-char motion spans; animating filter forces per-frame repaints of every span, and the user's browser repeatedly killed and reloaded the page (July 2026). Opacity/transform stay on the compositor.

**Rule 2: canvas illusions never redraw directly on `resize`.** Both illusion canvases guard (same width + height delta < 160px = ignore) and debounce 200ms.
**Why:** mobile URL-bar collapse fires resize storms during scroll; each drift redraw strokes ~10k arcs synchronously. Repeated main-thread stalls are what make mobile browsers kill the page. Bonus: the star field would visibly re-roll on ungated regenerate.

**Rule 3: rAF loops must terminate at rest.** The kriya tick stops rescheduling once phase is "done".

**How to apply:** any new animated text or canvas effect on this page must follow the same three rules; if the user again reports "crashing and reloading", audit for reintroduced filter/blur animations, ungated resize redraws, or immortal rAF loops before anything else.
