# Memory Index

- [Breath audio decisions](breath-audio-decisions.md) — NO background music bed on /breath ever (two beds rejected); only bowl, mantra clips, narration.

- [Media toolchain quirks](media-toolchain.md) — no python/pip; poppler + ffmpeg; noise-vocoder garble recipe (verify via STT); spectrogram-first sound diagnosis; narration voice.
- [Breath page verification](breath-page-verification.md) — timed kriya + settle-commit scroll beats: test with screenshot-first, phase-from-line reading, or you get false failures.
- [Breath page performance](breath-page-performance.md) — no per-char filter:blur animations; guard+debounce canvas resize redraws; stop rAF loops at rest, or browsers kill/reload the page.
