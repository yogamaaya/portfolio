---
name: Breath page verification
description: How to test the /breath timed kriya and scroll-driven beats without false failures.
---

# Verifying the /breath ritual page

**Rule:** the kriya is a real-time ritual (settle 3s, then FOUR rounds of 4-7-8 breathing, ~84s total, then auto-scroll to the mantra). Headless testers run ~5-10s late PER STEP (screenshots, DOM probes), so timed assertions drift badly.

**Why:** two tester rounds came back "failure" that were actually correct behavior captured at a later phase than intended.

**Round map (July 2026, user-approved):**
- Rounds 1-2: drift ring pattern visible through ALL phases. Near-black on a round-1/2 line = FAILURE.
- Round 3: deliberate VOID. Blank near-black screen (only dim aura, fixation dot, text) for the whole round; "what isn't there still appears" is its hold line. Rings or stars visible on a round-3 line = FAILURE; near-black = SUCCESS.
- Round 4: star field (mandala noise), reveal tween at the end.

**How to apply:**
- Never assert one specific kriya line at a wall-clock time. Any line from the (round, phase) map is evidence the ritual is running; identify the phase FROM the observed line.
- For early-round visuals, instruct: screenshot FIRST, DOM checks after. The DOM probe alone can eat a whole phase.
- Scroll beats commit only after the scroll RESTS in a band (settle-commit debounce); testers must pause 2s+ after each scroll before asserting text, and CharFade takes seconds to fully materialize.
- Narrated beat display text must keep the exact recorded words; visual copy edits elsewhere are fine.
