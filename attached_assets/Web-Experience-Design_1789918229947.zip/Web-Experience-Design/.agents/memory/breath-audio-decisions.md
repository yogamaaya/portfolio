---
name: Breath page audio decisions
description: Locked audio design decisions for the /breath scrollytelling page
---

# /breath audio decisions

## No background music bed. Ever.
The page has NO looping background music. The only audio is: bowl strike sfx (kriya), the two mantra clips (garbled + clear), and the 14 narration beats.
**Why:** Two beds were built and both rejected by the user (July 2026): first an ominous drone with high shimmer, then a synthesized 432 Hz pad the user called "grainy and painful". The user then ordered full removal, including during narration.
**How to apply:** Never reintroduce a music bed, ambient loop, or pad on /breath, even "improved" ones, unless the user explicitly asks for background music. The audio provider intentionally has no bed element and no ducking/suppression machinery; keep it that way.

## One voice at a time
Any new cue (narration or sfx) supersedes whatever is still ringing with a short fade instead of overlapping it. **Why:** overlapping tails (bowl under mantra, doubled clips) were an early complaint. Superseded pending play() rejections surface as AbortError; that is expected, not a bug.
