---
name: Media toolchain quirks
description: What's available for PDF/audio processing in this env, the garbled-speech illusion recipe, and the narration voice used on /breath.
---

## No Python in this environment
`python3`/`pip` are NOT installed. **Why:** first attempt to use PyMuPDF failed (exit 127). Poppler tools (`pdftotext`, `pdfimages`, `pdftoppm`), `ffmpeg`, and `node` ARE on PATH.
**How to apply:** for PDF text/image extraction reach for poppler first; only install a Python module if poppler can't do the job. Avoid `ls /nix/store` (huge — times out the shell).

## Garbled-speech "pop-out" illusion recipe (used on /breath)
Phase randomization (ffmpeg afftfilt) does NOT garble speech: the magnitude spectrogram survives, so STT recovered 6/6 mantra words even at win_size 4096 + afreqshift + lowpass, and the user could understand it by ear. **What works:** few-band noise vocoding (Davis et al. 2005), done in a small node DSP script: decode to f32 mono via ffmpeg; for each of ~4 log-spaced bands 120-6000 Hz do biquad bandpass -> 20 Hz one-pole envelope -> modulate bandpassed white noise, RMS-match per band; sum, RMS-match to reference loudness, encode mp3. Acceptance: STT returns UNINTELLIGIBLE and broadband envelope correlation with the clear take stays >0.9 (rhythm intact for the primed pop-out).
**Verify objectively, never by assumption:** Gemini inline audio via AI-integrations proxy: POST `${AI_INTEGRATIONS_GEMINI_BASE_URL}/models/gemini-2.5-flash:generateContent` with header x-goog-api-key and inlineData mp3 base64 (base URL already includes the API version; appending /v1beta gives INVALID_ENDPOINT; each contents entry MUST carry role:"user" or the API 400s with "Please use a valid role"). Clear take must transcribe exactly; garbled must return UNINTELLIGIBLE. Note: externalApi__elevenlabs `body` must be a JSON Record, so multipart STT uploads are impossible through that callback.
**How to apply:** the /breath mantra flow depends on the garbled and clear files being generated from the SAME TTS take.

## Diagnose sound complaints with spectrograms, not guesses
When the user complains about "a sound", spectrogram every long-running audio asset first (`ffmpeg -lavfi showspectrumpic`). **Why:** a /breath complaint about "the ominous bowl" was actually the looping background bed (drone had 16 kHz shimmer bursts every loop); the bowl strike got replaced first, wasting a round. **How to apply:** locate the offending file by its spectral signature before editing anything; a continuous complaint means a looping asset, not a one-shot sfx. For calm loop beds: keep every sine and LFO frequency on the 1/duration Hz grid so the loop point is exact, and keep all content below ~650 Hz for "warm, no sparkle".

## Site narration voice (keep consistent)
/breath narration + mantra use ElevenLabs voice "apex-drift" (voiceId `lYYrqMJ8tyW54mjnAF9r`), voiceSettings `{ stability: 0.5, similarity_boost: 0.8, style: 0.35, speed: 0.85 }` (mantra at speed 0.8). **Why:** future narration clips for this site must not switch voices mid-experience.
