# /breath — content contract (exact copy + asset map)

All static assets live in `artifacts/experience/public/breath-assets/` and are served at
`${import.meta.env.BASE_URL}breath-assets/...`. All audio files listed below WILL exist at runtime
(they are being generated in parallel; reference the paths, do not verify contents).

## 1. POSTER HERO (use this copy verbatim)

Headline (the catchy first words): **YOU ARE BEING BREATHED.**

Sub-copy:
"Every few seconds the universe inhales you back — and exhales you into existence again.
This is a guided descent into the rendering engine of reality: breathe as instructed,
watch still stars begin to spin, hear noise become meaning. Then take the book home."

Credit line: "Breath of the Self — Snigdha Motadaka"

A "begin" interaction is REQUIRED here (tap/click) — it unlocks the Web Audio / <audio> context
(browser autoplay policy) and starts the ambient drone `breath-assets/audio/drone.mp3` (looped, low volume ~0.25).

## 2. KRIYA BREATH SCROLLYTELLING (content beats; visual execution is yours)

Scroll-driven guided breathing. Suggested beats (keep the instructions/timings, stage them however you want):
- "Sit tall. Soften your jaw. Notice the breath that is already happening — you are not doing it."
- Round 1 — slow ujjayi: "Inhale through the nose — 4… Hold — 4… Exhale slowly — 6…" (repeat cycles; a breathing element should expand/hold/contract in sync)
- Round 2 — deepen: "Inhale — 4… Hold — 7… Exhale, spine tall, breath rising from the base — 8…"
- Round 3 — quicken: shorter, rhythmic breaths ("in–out… in–out…") that accelerate and hand off into the star visuals.
- Use `breath-assets/audio/bowl.mp3` (soft singing-bowl strike) sparingly at phase transitions.
- Timing sync matters more than decoration: the expand/hold/contract animation must actually track the stated counts.

## 3. PSYCHEDELIC ILLUSION SECTION — "the still sky that spins" (research-grounded; implement all three)

a) **Peripheral drift / Rotating Snakes (Kitaoka 2003)** — rings of dark star/wedge shapes built with the
   asymmetric luminance ordering (black → dark violet → white → dim violet) around each ring. When the eye
   saccades, STATIC rings appear to rotate. Render on canvas or SVG. Dark palette: near-black sky, deep violet stars.
   Also add a genuinely slow-rotating layer so the effect is undeniable on all displays.
   Caption idea: "These stars are not moving. Your renderer is."
b) **Motion aftereffect / waterfall illusion** — a stage where the user holds the breath (hold — 30s or shorter ~20s)
   while staring at a slowly rotating spiral with a fixation dot. When it stops, the next block of text appears to
   swell/warp. Instruct: "Keep your eyes on the dot. Do not blink more than you must." Then: "Now look at the words."
c) **Troxler fading (1804)** — fixation dot, faint violet blobs in the periphery that objectively persist but
   perceptually vanish while fixating. Caption: "Whatever you stop attending to, the renderer stops rendering."

Tie-line after the illusions (use close to verbatim): "None of that was a trick played on reality. It was reality —
perception is a render, and the render obeys attention."

## 4. MANTRA POP-OUT (audio illusion — the core mind-trick; exact flow)

Research framing (show subtly, small print): sine-wave speech (Remez et al., Science, 1981) and noise-vocoded
speech "pop-out" (Davis et al., 2005) — degraded speech is gibberish until you know the words; after seeing the
text, the same audio becomes instantly intelligible and cannot be un-heard.

Flow (scroll-staged):
1. A play control: "Listen. What is this voice saying?" → plays `breath-assets/audio/mantra-garbled.mp3` (spectrally scrambled — genuinely unintelligible).
2. Let them replay. Text: "Nothing? Noise? Hold that."
3. On further scroll, reveal the mantra text, large: **"Surrender. Let the universe breathe through you."**
4. A second play control: "Now listen again." → plays the SAME `mantra-garbled.mp3` file (this matters — same file, do not swap in a clean one).
   The voice now speaks clearly through the noise.
5. Then optionally offer `breath-assets/audio/mantra-clear.mp3` ("hear it unveiled").
6. Closing line: "The sound never changed. You did. Knowledge is the decryption key of perception — this is what the book means by rendering."

## 5. "THE RENDERING" SCROLLYTELLING (condensed Chapter 0, narrated)

One sentence-beat at a time fades in as the user scrolls (sticky stage, text crossfades). When a beat becomes
active, play its narration clip (each beat has its own mp3; stop the previous clip when a new one starts; show a
small mute toggle). Voice is Sarasvatī — the book's narrator.

Beats (display text verbatim; audio files are `breath-assets/audio/render-01.mp3` … `render-15.mp3` in order):

1. "In the silence of the Void, I am the potential energy of sound."
2. "I am Sarasvatī. The compiler of this story — and of all stories."
3. "This universe is not dead matter. It is a dream rendering itself in real time, computed by the attention of its one observer."
4. "Beneath everything runs a pulse. Spanda — the heartbeat of awareness."
5. "Unmeṣa. The opening. The yes of remembrance."
6. "Nimeṣa. The closing. The no of forgetting."
7. "The blink repeats faster than thought can follow — and the flicker hardens into what you call the world. Frames, projected at infinite speed, pretending to be motion."
8. "Māyā is not a lie. She is the rendering engine — computing the pulse into a world dense enough to be touched."
9. "Fifty vibrations compile it: sixteen vowels of pure consciousness carrying thirty-four consonants of executable form."
10. "Karma is not reward and punishment. Karma is cache. What has run often runs easily — and what runs easily, runs again."
11. "Retrieve a pattern consciously, and you can rewrite it. Retrieve it unconsciously, and the pattern runs you."
12. "Power is the current of feeling divided by the square of your resistance. Feel everything. Resist nothing."
13. "Universes appear and vanish with the breathing of the cosmic Lord. Your entire life is one detail inside a single out-breath."
14. "You did not arrive at this sentence by accident. The rendering engine delivered you here."
15. "To hold true power in this world, you must first surrender — and let the Universe breathe through you."

Beat 12 may show the equation P = I/R². Beat 15 should feel like the destination of the whole page.

## 6. FINAL BOOK LANDING

The physical book. Cover image: `breath-assets/book-cover.jpg` (1024×1536 portrait — a cream linen hardcover,
hand-inked calligraphy "the breath / Your Self", author "snigdha motadaka"). Present it AS a physical object
(dimensional, precious — it is the only light-colored object on an otherwise dark page; let it glow).

- Title: "Breath of the Self" — Author: Snigdha Motadaka
- CTA: "Hold the physical book" → use the constant `BOOK_PURCHASE_URL` defined at the top of the page file,
  set to "#" with a `// TODO: replace with the real purchase link` comment (the real URL is coming from the user).
- A closing whisper after the CTA, e.g. "exhale." — then the site Footer.

## SITE CONTINUITY

This page joins an existing experience: near-black void backgrounds, deep violet/indigo auras, Bodoni Moda
(italic serif) display type. Same universe, deeper chamber. The existing `Footer` component
(`src/components/Footer.tsx`) must be included at the very end.

## AUDIO ASSET MAP (all will exist at runtime)

- `breath-assets/audio/drone.mp3` — ambient drone bed, loop after "begin" tap, volume ~0.2–0.3
- `breath-assets/audio/bowl.mp3` — singing bowl strike for breath-phase transitions
- `breath-assets/audio/mantra-garbled.mp3` — scrambled mantra (sections 4.1 and 4.4 — SAME file both times)
- `breath-assets/audio/mantra-clear.mp3` — clear mantra
- `breath-assets/audio/render-01.mp3` … `render-15.mp3` — one clip per beat in section 5
