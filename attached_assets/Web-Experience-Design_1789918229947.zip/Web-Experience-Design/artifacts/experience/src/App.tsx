import { Switch, Route, Router as WouterRouter } from "wouter";
import ExperiencePage from "@/pages/ExperiencePage";
import VideoPlayerPage from "@/pages/VideoPlayerPage";
import LegalPage from "@/pages/LegalPage";
import BreathPage from "@/pages/BreathPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={ExperiencePage} />
      <Route path="/video" component={VideoPlayerPage} />
      <Route path="/legal" component={LegalPage} />
      <Route path="/breath" component={BreathPage} />
    </Switch>
  );
}

function App() {
  return (
    <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
      <Router />
    </WouterRouter>
  );
}

export default App;
