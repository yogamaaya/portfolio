import fs from 'node:fs';
import assert from 'node:assert/strict';
import ts from 'typescript';
const uri=path=>'data:text/javascript;base64,'+Buffer.from(ts.transpileModule(fs.readFileSync(path,'utf8'),{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText).toString('base64');
const {withDeadline}=await import(uri('lib/cyma/async.ts'));
const signal=new AbortController();assert.equal(await withDeadline(Promise.resolve(42),signal.signal,100,'timeout'),42);
await assert.rejects(withDeadline(new Promise(()=>{}),signal.signal,5,'timeout'),/timeout/);
const cancel=new AbortController(),waiting=withDeadline(new Promise(()=>{}),cancel.signal,1000,'timeout');cancel.abort();await assert.rejects(waiting,{name:'AbortError'});
const {BOWL_PARTIALS,bowlEnvelope}=await import(uri('lib/cyma/physics.ts'));
// Verify the audible summed oscillator signal is clearly above the old level,
// while keeping peak headroom, including strikes after multiple loops.
let sum=0,max=0,count=0;for(let i=0;i<24000*26;i++){const t=i/24000;let sample=0;for(const [f,a,d] of BOWL_PARTIALS)sample+=.24*.55*a*bowlEnvelope(t,d)*Math.sin(2*Math.PI*f*t);max=Math.max(max,Math.abs(sample));if(t>.15){sum+=sample*sample;count++}}
const rms=Math.sqrt(sum/count);assert.ok(rms>.035&&max<.8);
console.log(JSON.stringify({passed:true,timeoutAndCancellation:true,bowlRMS:+rms.toFixed(4),bowlPeak:+max.toFixed(4)}));
// Exercise actual AudioPlayer scheduling with an advancing audio clock. A curve
// in the past is clamped exactly as in the browser that exposed this regression.
const audioSource=fs.readFileSync('lib/cyma/audio.ts','utf8').replace("'./physics'",JSON.stringify(uri('lib/cyma/physics.ts')));
const {AudioPlayer}=await import('data:text/javascript;base64,'+Buffer.from(ts.transpileModule(audioSource,{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText).toString('base64'));
let interval;
const realInterval=globalThis.setInterval,realClear=globalThis.clearInterval;
globalThis.setInterval=fn=>{interval=fn;return 1};globalThis.clearInterval=()=>{};
class Context{
 time=1;state='running';destination={};gains=[];oscillators=[];
 get currentTime(){this.time+=.002;return this.time}
 resume(){return Promise.resolve()}
 createGain(){const events=[],ctx=this;const node={events,connect(){},disconnect(){},gain:{setValueAtTime(){},linearRampToValueAtTime(){},setValueCurveAtTime(curve,start,duration){const actual=Math.max(start,ctx.currentTime);assert.ok(!events.length||actual>=events.at(-1).end,'Audio curves must not overlap');events.push({start:actual,end:actual+duration});}}};this.gains.push(node);return node}
 createOscillator(){this.time+=.025;const o={frequency:{value:0},connect(){},disconnect(){},stop(){},setPeriodicWave(){},start:t=>assert.ok(t>=this.currentTime,'First oscillator is scheduled ahead of the audio clock')};this.oscillators.push(o);return o}
 createPeriodicWave(){return {}}
 close(){return Promise.resolve()}
}
globalThis.AudioContext=Context;
const audio=new AudioPlayer();await audio.play('bowl',0);assert.equal(audio.ctx.oscillators.length,6);audio.ctx.time=83;interval();assert.equal(audio.ctx.gains.slice(1).every(g=>g.events.length>=3),true);audio.stop();assert.equal(audio.nodes.length,0);assert.equal(audio.envelopes.length,0);
globalThis.setInterval=realInterval;globalThis.clearInterval=realClear;
console.log(JSON.stringify({bowlScheduling:true,backgroundRecovery:true,cleanup:true}));
