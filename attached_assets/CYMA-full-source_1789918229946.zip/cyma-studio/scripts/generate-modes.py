"""Rigid cylindrical wall: J_m'(alpha)=0, excluding the zero-volume mode.
SciPy tables are generated once; no approximated frequency-to-petal mapping.
"""
import json
import numpy as np
from scipy.special import jnp_zeros, jv
r=np.linspace(0,1,1024)
rows=[]; meta=[]
for m in range(17):
    for n,a in enumerate(jnp_zeros(m,80),1):
        y=jv(m,a*r)
        norm=np.max(np.abs(y))
        # Area norm for the normalized cosine eigenmode.
        integral=(1-(m/a)**2)*jv(m,a)**2/(norm*norm)*(1 if m==0 else .5)
        coupling=jv(m,a*.62)/norm/integral
        meta.append({'m':m,'n':n,'alpha':float(a),'coupling':float(coupling)})
        rows.append((y/norm).astype('<f4'))
np.array(rows,dtype='<f4').tofile('public/physics/radial.bin')
open('public/physics/modes.json','w').write(json.dumps(meta,separators=(',',':')))
print(f'Generated {len(meta)} Neumann modes; radial resolution {len(r)}')
