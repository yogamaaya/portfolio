import os,re,json,time
import numpy as np
import moderngl
from pathlib import Path
root=str(Path(__file__).resolve().parents[1])
src=open(root+'/lib/cyma/shaders.ts').read()
shaders=dict(re.findall(r'export const (\w+)=`([\s\S]*?)`;',src))
ctx=moderngl.create_standalone_context(backend='egl')
print('Renderer:',ctx.info['GL_RENDERER'],flush=True)
pairs=[('quadVertex','fieldFragment'),('quadVertex','forceFragment'),('particleUpdateVertex','emptyFragment'),('quadVertex','surfaceFragment'),('particleDrawVertex','particleDrawFragment')]
programs=[]
for v,f in pairs:
 p=ctx.program(vertex_shader=shaders[v],fragment_shader=shaders[f],varyings=['nextState'] if v=='particleUpdateVertex' else [])
 programs.append(p)
print('PASS: all five actual GLSL ES 3.0 programs compile and link.',flush=True)
# Texture pipeline and the production adaptive-preview particle budget.
radial=ctx.texture((1024,1360),1,open(root+'/public/physics/radial.bin','rb').read(),dtype='f4');radial.filter=(moderngl.NEAREST,moderngl.NEAREST)
size=int(os.environ.get("CYMA_TEST_FIELD","256"));field=ctx.texture((size,size),4,dtype='f2');force=ctx.texture((size,size),4,dtype='f2');field.filter=force.filter=(moderngl.LINEAR,moderngl.LINEAR)
field.repeat_x=field.repeat_y=force.repeat_x=force.repeat_y=False
fb=ctx.framebuffer([field]);ffb=ctx.framebuffer([force]);fb.use();ctx.viewport=(0,0,size,size);radial.use(0)
modes=json.load(open(root+'/public/physics/modes.json'));idx=next(i for i,m in enumerate(modes) if m['m']==6 and m['n']==15)
coeff=np.zeros((32,4),np.float32);coeff[0]=[idx,6,.9,.1];p=programs[0];p['modes'].write(coeff.tobytes());p['count']=1;p['radial']=0;ctx.vertex_array(p,[]).render(vertices=3)
ffb.use();field.use(0);p=programs[1];p['field']=0;p['size']=size;ctx.vertex_array(p,[]).render(vertices=3)
force_bytes=np.frombuffer(force.read(),np.float16).reshape(size,size,4)*255;assert force_bytes[:,:,0].max()>128 and force_bytes[:,:,0].min()<128
count=int(os.environ.get("CYMA_TEST_COUNT","262144"));b1=ctx.buffer(reserve=count*16);b2=ctx.buffer(reserve=count*16);p=programs[2];p['forceField']=0;p['dt']=1/60;p['tick']=0;p['initialize']=1;force.use(0);vao1=ctx.vertex_array(p,[(b1,'4f','state')]);vao2=ctx.vertex_array(p,[(b2,'4f','state')]);start=time.time();vao1.transform(b2,vertices=count,mode=moderngl.POINTS);ctx.finish();initial=np.frombuffer(b2.read(size=16*8192),np.float32).reshape(-1,4).copy();assert np.isfinite(initial).all();assert np.max(np.linalg.norm(initial[:,:2],axis=1))<.981
p['initialize']=0
for i in range(12):
 p['tick']=i+1
 if i%2==0:vao2.transform(b1,vertices=count,mode=moderngl.POINTS)
 else:vao1.transform(b2,vertices=count,mode=moderngl.POINTS)
ctx.finish();final=np.frombuffer(b2.read(size=16*8192),np.float32).reshape(-1,4);assert np.isfinite(final).all();assert np.max(np.linalg.norm(final[:,:2],axis=1))<=.986;motion=np.linalg.norm(final[:,:2]-initial[:,:2],axis=1);assert np.max(motion)>.0001
# Final draw, same shader and buffers as the app.
wide=int(os.environ.get('CYMA_TEST_WIDE','0'));w,h=(1920,1080) if wide else (1080,1080)
out=ctx.texture((w,h),4,dtype='f1');ofb=ctx.framebuffer([out]);ofb.use();ctx.viewport=(0,0,w,h);field.use(0);p=programs[3];p['field']=0;p['resolution']=(w,h);p['wide']=float(wide);p['exposure']=2.2;ctx.vertex_array(p,[]).render(vertices=3)
p=programs[4];p['field']=0;p['resolution']=(w,h);p['wide']=float(wide);pixel_scale=max(1.5,min(2.2,w/650));p['pixelScale']=pixel_scale;p['dose']=min(.8,w*h/count*.68/(pixel_scale*pixel_scale));p['exposure']=2.2;ctx.enable(moderngl.BLEND | moderngl.PROGRAM_POINT_SIZE);ctx.blend_func=(moderngl.SRC_ALPHA,moderngl.ONE);ctx.vertex_array(p,[(b2,'4f','state')]).render(mode=moderngl.POINTS,vertices=count);ctx.finish();pix=np.frombuffer(out.read(),np.uint8).reshape(h,w,4);assert pix[:,:,:3].max()>60
if wide:
 assert np.max(pix[:4,:,:3])<3 and np.max(pix[-4:,:,:3])<3
 assert np.max(pix[:,:4,:3])<3 and np.max(pix[:,-4:,:3])<3
from PIL import Image
Path(root+'/.sites-runtime').mkdir(exist_ok=True)
Image.fromarray(pix[::-1]).save(root+'/.sites-runtime/gpu-verification.png')
print(json.dumps({'width':w,'height':h,'black_edges':bool(wide),'particles':count,'steps':12,'finite':True,'max_displacement':float(motion.max()),'elapsed_seconds':round(time.time()-start,2)}),flush=True)
