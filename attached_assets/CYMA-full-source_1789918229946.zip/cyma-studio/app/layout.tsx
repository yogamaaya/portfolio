import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CYMA — Digital water studio of sound",
  description: "Explore audio through a circular water-wave model. Create particle-rich cymatic visuals and export silent MP4 films.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
