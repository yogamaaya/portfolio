# CYMA

A local audio-to-water-wave studio. React/Vinext UI, WebGL 2 rendering with a Canvas 2D fallback, and silent 1920 × 1080 widescreen MP4 exports. Audio never leaves the browser.

## Wave and particle model

1,360 circular Neumann modes use finite-depth capillary-gravity dispersion, viscous damping and an explicit six-point Gaussian pressure drive. Complex modal envelopes retain state, and 32 rendering slots crossfade before reassignment. This is a carrier-averaged, reduced wave model; it does not integrate full Navier–Stokes or nonlinear Faraday instability.

Particles are now persistent Lagrangian tracers with position and velocity. The bounded gradient of the normalized wave-energy potential drives them, opposed by Stokes-style drag, with small diffusion and reflecting walls. Tracer coefficients and visual gain are illustrative and uncalibrated. These are tracer particles, not molecular water particles. Increasing count improves sampling, not the validity of the underlying physical assumptions.

WebGL 2 transform feedback retains particle position and velocity. Auto preview starts at 262,144 particles (8 MiB of state, versus the previous 64 MiB default) and can reduce the active count to 32,768 while keeping the surviving particles' motion. Light, balanced, and optional multi-million budgets remain available. A GPU fence prevents queuing frames behind an unfinished render, and slow frames reduce the budget. The display is limited to 30 fps, 1280 pixels per edge and roughly 1.2 megapixels, with a 256-square wave field. Device limits are read once, coefficient storage is reused, and angular harmonics are shared across modes. Paused and hidden canvases do not keep rendering.

The CPU fallback starts at 16,384 tracers on a 160-square field and 384-square density raster, adapting down to 4,096 tracers. It uses a cached color palette instead of per-pixel exponential lighting. Particle brightness is normalized for density. Bright contour illumination is derived from the same low-energy wave field, separate from the unchanged tracer forces; it is an optical display, not additional particle matter. Actual active count is always reported.

Export uses its own fixed rendering budget, a 512-square GPU field (or 256-square CPU field with 65,536 tracers), and the full 1920 × 1080 output. Preview load shedding does not alter export timing.

## Continuous drive and speech

Bowl strikes are summed causal envelopes with a smooth attack and continuing prior tails. Neither oscillator phase nor particle state resets at the 12-second strike interval. The audible bowl uses the same envelope function. Its initial curves are computed before choosing a future audio start time, preventing browser clamping from creating overlapping automation blocks. Scheduling also recovers after a throttled background tab. Selecting an audible preset enables sound during the user gesture; the visible source control always reports sound on/off. Bowl gain is balanced separately from pure tones and uploaded playback. Speech automatic gain is disabled for presets so bowl ringing can decay naturally. Preset changes preserve tracer motion; an explicit restart or seek resets history.

Audio uses a centered Hann STFT (8192 samples, 512-sample hop, 24 kHz), 32 peaks in the 20–1800 Hz range, interpolation between spectral ridges, and corrected peak magnitudes. Optional gentle noise subtraction retains 22% of the local spectrum. For uploaded audio, automatic gain up to 40× and a user sensitivity control lift quiet speech without altering playback audio. True digital silence creates no drive. The original MP3 stays on the device.

## Export

WebCodecs H.264 when supported, with a WASM H.264 worker fallback. Export integrates a fresh particle history at the selected budget (262,144 GPU particles for Auto), starting at the beginning of the decoded track, and samples frames at 30 fps. The final frame is shortened and muxed with a 57,600 Hz timebase. No interface overlays or audio stream. Output is 1920 × 1080 (16:9 Full HD). A wide, isotropic camera crop fills the frame without stretching the circular physical modes; an elliptical smoothstep vignette and vessel-edge feather blend the field into pure black at the frame edges. The fade is spatial, not a fade-out at the end of the track. Both renderers and encoder paths use this composition. The software MP4 remux reads the encoded dimensions instead of assuming a square. Input limits: 50 MB / 8 minutes. Completion opens an MP4-ready dialog with a playable preview, file size, duration, direct Save MP4 link, and an open-video fallback. A persistent Save MP4 action remains after dismissing the dialog. Downloads use a real user click, not a synthetic click after a long render. Encoder waits are bounded and cancellable; native codec failures retry through the compatible worker encoder.

## Verification

- `node scripts/verify-delivery.mjs`: bounded encoder waits, abort behavior, bowl output headroom, real AudioPlayer scheduling against an advancing clock, background recovery, and audio-node cleanup.

- `node scripts/verify-model.mjs`: reference Neumann root, depth response, distinct frequency responses, exact-silence behavior, quiet-speech-harmonic sensitivity, FFT frequency/amplitude accuracy, and continuity across repeated bowl strikes and rendering-slot changes.
- `python scripts/verify-gpu.py`: requires moderngl, numpy, Pillow, and EGL. Compiles all five actual GLSL ES programs, executes the field and transform-feedback pipeline, checks finite in-vessel positions and nonzero motion, and renders the result. `CYMA_TEST_COUNT=8388608` exercises the maximum count. Use `CYMA_TEST_WIDE=1` to test the 1920 × 1080 composition and its black perimeter. Run from the repository root.
- Current EGL/llvmpipe tests pass at the 262,144-particle auto budget and at 2,097,152 particles. This verifies shader execution, not a guaranteed frame rate on user hardware.
- `node scripts/verify-rendering.mjs`: adaptive budget limits, capped display resolution, finite particle state, default pattern brightness, and a CPU draw benchmark. In the development runtime the revised fallback measured approximately 5.7 ms median / 6.1 ms p95 per frame; this excludes browser compositing and is not a device FPS guarantee.
- Browser QA used the CPU renderer and software encoder. A synthesized quiet spoken clip at roughly 0.025 RMS produced visible emergent patterns. A decoded 2.137-second MP3 exported as 65 H.264 frames at 1920 × 1080, no audio stream, with a measured duration of 2.136997 seconds. The GPU composition has a black perimeter; decoded software H.264 frames retain the smooth fade with minor near-black compression noise.
- WebGL is unavailable in the preview browser; GPU execution was tested separately through EGL. WebMCP remains feature-detected; the preview browser does not expose modelContext.

`scripts/generate-modes.py` requires SciPy and NumPy to regenerate the committed numerical mode assets.
