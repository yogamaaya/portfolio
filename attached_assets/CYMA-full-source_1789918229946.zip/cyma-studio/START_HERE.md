# CYMA — Digital water studio of sound

This is the complete source snapshot for the published CYMA site, version 6,
including the latest header, footer, privacy dialog, and expanded physics guide.

Source commit: `73d78bcad42076870e554d3a26f76a665f4d09f0`

## Run on your computer

1. Extract this ZIP and open a terminal inside the `cyma-studio` folder.
2. Install Node.js 22.13 or later, and pnpm 11.25.0 (the version pinned in
   `package.json`). If Corepack is available, run:

   ```sh
   corepack enable
   corepack prepare pnpm@11.25.0 --activate
   ```

   If Corepack is unavailable, install the pinned pnpm version with:

   ```sh
   npm install --global pnpm@11.25.0
   ```

3. Install dependencies and start the app:

   ```sh
   pnpm install --frozen-lockfile
   pnpm dev
   ```

4. Open http://localhost:5173 in your browser. Use the address printed by the
   development server if that port is already occupied.

The ordinary development commands use the portable execution profile
when no checkout-local profile is present. You do not need the original
managed development environment or its Linux installation helper.
No API keys, database, or external audio service are needed for the studio.
The first dependency installation needs an internet connection.

## Build and preview locally

```sh
pnpm build
pnpm start
```

`pnpm start` serves the built Cloudflare Worker locally through Wrangler.
Open the local URL printed in the terminal. This is a local preview command,
not a command that publishes or replaces the hosted site.

The source includes the original Sites/Vinext hosting configuration. To deploy
to a different host, adapt the deployment configuration to that host. The
portable development profile uses mock hosting authentication for local work.

## Where to look

- `app/page.tsx`: studio controls, audio playback, uploads, and export UI.
- `app/globals.css`: responsive layout, colors, and dialog styles.
- `components/cyma-info.tsx`: privacy notice and physics explanations.
- `lib/cyma/physics.ts`: wave modes, audio drives, and persistent modal response.
- `lib/cyma/renderer.ts` and `shaders.ts`: WebGL 2 particles and field rendering.
- `lib/cyma/canvas-renderer.ts`: Canvas 2D fallback.
- `lib/cyma/audio.ts` and `public/analyze-worker.js`: local audio decoding,
  spectrum analysis, and playback.
- `lib/cyma/export.ts`, `remux.ts`, `composition.ts`, and
  `public/encode-worker.js`: silent 1920 × 1080 MP4 export and widescreen fade.
- `public/physics/`: numerical wave-mode data, already generated and included.
- `public/vendor/`: bundled browser video encoder and its attribution notice.
- `scripts/generate-modes.py`: optional mode-data regeneration (NumPy/SciPy).
- `scripts/verify-*.mjs` and `scripts/verify-gpu.py`: model and renderer checks.
- `README.md`: implementation notes and prior validation results.
- `package.json`, `pnpm-lock.yaml`: pinned dependency setup.

## Included and required files

All 124 files tracked in the published source snapshot are included unchanged,
plus this guide. Keep the complete folder when installing or building; its
configuration files are part of the project. Installed dependencies and Git
history are not bundled. No uploaded audio or finished user videos are included.

The browser performs audio analysis, simulation, and encoding locally. Use a
modern browser with WebGL 2 for the accelerated renderer. A Canvas 2D renderer
and browser-local WASM encoder provide fallbacks. Browser capabilities and
hardware determine rendering and export speed.

Preserve the bundled third-party license and notice files when redistributing.
